# Reversi_Iced
A reversi (othello) clone made in in [iced-rs](https://github.com/iced-rs/iced). It doesn't run particularly well (the computer opponent might be sluggish sometimes). Too bad.
<details>Also, I totally stole their custom circle widget.</details>
